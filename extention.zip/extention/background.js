chrome.runtime.onInstalled.addListener(function(){
    alert("Merci d'avoir mis à jour ou installé mon extention ! ")
  });